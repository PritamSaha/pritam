package testcases;

import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import base.TestBase;

public class LoginTest extends TestBase {
	@Test
	public void loginAsAdmin() throws InterruptedException
	{
		Thread.sleep(3000);
		
		driver.findElement(By.xpath(OR.getProperty("Username"))).sendKeys("Admin");
		driver.findElement(By.xpath(OR.getProperty("Password"))).sendKeys("admin123");
		//driver.findElement(By.xpath(".//*[@id='txtPassword']")).sendKeys("admin123");
		driver.findElement(By.xpath(OR.getProperty("Login"))).click();
		Thread.sleep(3000);
		Assert.assertTrue(isEelementPresent(By.xpath(OR.getProperty("WelcomeMessage"))),"Login Failed");

	}
}
