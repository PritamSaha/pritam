package testcases;

import org.openqa.selenium.By;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import base.TestBase;

public class NewUser extends TestBase{
	@Test(dataProvider="getData")
	public void newUser(String EmpName,String NewUsername,String NewPwd,String CnfPwd) throws InterruptedException
	
	{
		driver.findElement(By.xpath(OR.getProperty("Admin"))).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("Add"))).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath(OR.getProperty("EmpName"))).sendKeys(EmpName);
		driver.findElement(By.xpath(OR.getProperty("NewUsername"))).sendKeys(NewUsername);
		driver.findElement(By.xpath(OR.getProperty("NewPwd"))).sendKeys(NewPwd);
		driver.findElement(By.xpath(OR.getProperty("CnfPwd"))).sendKeys(CnfPwd);
		driver.findElement(By.xpath(OR.getProperty("Save"))).click();
		Thread.sleep(1000);
		
	}
	@DataProvider
	public Object[][] getData()
	{
	String sheetName="NewUser";
	int rows = excel.getRowCount(sheetName);
	int cols = excel.getColumnCount(sheetName);	
	Object[][] data=new Object[rows-1][cols];
	for (int rowNum=2; rowNum <= rows; rowNum++) {
	for (int colNum=0;colNum<cols;colNum++)	
	{
	data[rowNum - 2][colNum]=excel.getCellData(sheetName,colNum,rowNum)	;
	}
	}
	return data;
	}
		
		
	}


